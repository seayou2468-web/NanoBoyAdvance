// Copyright Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the license.txt file included.

#pragma once

#include <array>
#include <memory>
#include "../../../common/common_types.h"
#include "object.h"
#include "../../../common/serialization/boost_all_serialization.h"

namespace Kernel {

enum class ResourceLimitCategory : u8 {
    Application = 0,
    SysApplet = 1,
    LibApplet = 2,
    Other = 3,
};

enum class ResourceLimitType : u32 {
    Priority = 0,
    Commit = 1,
    Thread = 2,
    Event = 3,
    Mutex = 4,
    Semaphore = 5,
    Timer = 6,
    SharedMemory = 7,
    AddressArbiter = 8,
    CpuTime = 9,
    Max = 10,
};

class ResourceLimit final : public Object {
public:
    explicit ResourceLimit(KernelSystem& kernel);
    ~ResourceLimit() override;

    /**
     * Creates a resource limit object.
     */
    static std::shared_ptr<ResourceLimit> Create(KernelSystem& kernel,
                                                 ResourceLimitCategory category,
                                                 std::string name = "Unknown");

    std::string GetTypeName() const override {
        return "ResourceLimit";
    }
    std::string GetName() const override {
        return m_name;
    }

    static constexpr HandleType HANDLE_TYPE = HandleType::ResourceLimit;
    HandleType GetHandleType() const override {
        return HANDLE_TYPE;
    }

    ResourceLimitCategory GetCategory() const {
        return m_category;
    }

    s32 GetCurrentValue(ResourceLimitType type) const;
    s32 GetLimitValue(ResourceLimitType type) const;

    void SetCurrentValue(ResourceLimitType name, s32 value);
    void SetLimitValue(ResourceLimitType name, s32 value);

    bool Reserve(ResourceLimitType type, s32 amount);
    bool Release(ResourceLimitType type, s32 amount);

    void ApplyAppMaxCPUSetting(std::shared_ptr<Kernel::Process>& process, u8 exh_mode,
                               u8 exh_cpu_limit);

private:
    Kernel::KernelSystem& kernel;
    ResourceLimitCategory m_category;
    using ResourceArray = std::array<s32, static_cast<std::size_t>(ResourceLimitType::Max)>;
    ResourceArray m_limit_values{};
    ResourceArray m_current_values{};
    std::string m_name;

private:
    friend class MikageSerialization::access;
    template <class Archive>
    void serialize(Archive& ar, const unsigned int);
};

class ResourceLimitList {
public:
    explicit ResourceLimitList(KernelSystem& kernel);
    ~ResourceLimitList();

    /**
     * Retrieves the resource limit associated with the specified resource limit category.
     * @param category The resource limit category
     * @returns The resource limit associated with the category
     */
    std::shared_ptr<ResourceLimit> GetForCategory(ResourceLimitCategory category);

private:
    std::array<std::shared_ptr<ResourceLimit>, 4> resource_limits;

    friend class MikageSerialization::access;
    template <class Archive>
    void serialize(Archive& ar, const unsigned int);
};

} // namespace Kernel

BOOST_CLASS_EXPORT_KEY(Kernel::ResourceLimit)
BOOST_CLASS_EXPORT_KEY(Kernel::ResourceLimitList)
CONSTRUCT_KERNEL_OBJECT(Kernel::ResourceLimit)
CONSTRUCT_KERNEL_OBJECT(Kernel::ResourceLimitList)
