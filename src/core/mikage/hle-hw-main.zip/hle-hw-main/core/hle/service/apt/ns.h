// Copyright Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the license.txt file included.

#pragma once

#include "../../../../common/common_types.h"
#include "../../kernel/process.h"
#include "../fs/archive.h"
#include "../service.h"

namespace Core {
class System;
}

namespace Service::NS {

/// Loads and launches the title identified by title_id in the specified media type.
std::shared_ptr<Kernel::Process> LaunchTitle(Core::System& system, FS::MediaType media_type,
                                             u64 title_id);

/// Reboots the system to the specified title.
void RebootToTitle(Core::System& system, FS::MediaType media_type, u64 title_id,
                   std::optional<Kernel::MemoryMode> mem_mode);

} // namespace Service::NS
